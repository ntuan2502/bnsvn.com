<?php $__env->startSection('css'); ?>
<title>Sửa hệ phái</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Sửa hệ phái</h2>
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/admin">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a>Hệ phái</a>
            </li>
            <li class="breadcrumb-item active">
                <strong>Sửa hệ phái</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox ">
                <div class="ibox-title">
                    <h5>Sửa hệ phái</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-wrench"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="#" class="dropdown-item">Config option 1</a>
                            </li>
                            <li><a href="#" class="dropdown-item">Config option 2</a>
                            </li>
                        </ul>
                        <a class="close-link">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <form action="" method="POST" class="form form--basic">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="name">Tên hệ phái</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" id="name" name="name" value="<?php echo e($hephai->name); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="abstract">Mô tả</label>
                            <div class="col-sm-10">
                                <textarea class="form-control" name="abstract" id="abstract" rows="5"><?php echo e($hephai->abstract); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="element">Hệ</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" id="element" name="element" value="<?php echo e($hephai->element); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label" for="icon_url">Icon URL</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="text" id="icon_url" name="icon_url" value="<?php echo e($hephai->icon_url); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Hình ảnh</label>
                            <div class="col-sm-10">
                                <img style="width: 9rem;" id="preview" src="<?php echo e($hephai->icon_url); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-12">
                                <button type="submit" class="btn btn-primary pull-right">Xác nhận</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    jQuery(document).ready(function($) {
        $('#icon_url').bind('input', function() {
            $('#preview').attr('src', $(this).val());
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\bnsvn\resources\views/admin/hephai/sua.blade.php ENDPATH**/ ?>