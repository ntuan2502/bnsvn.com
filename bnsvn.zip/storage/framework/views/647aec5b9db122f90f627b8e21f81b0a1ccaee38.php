<?php $__env->startSection('header'); ?>
<title><?php echo e($category->name); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div>
  <div class="hero-wrap hero-bread" style="background-image: url(<?php echo e(asset($category->background_url)); ?>);">
    <div class="overlay" style="opacity: .6; width: 100%; background: #000000;"></div>
    <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
        <!-- <div class="col-md-9 ftco-animate text-center">
          <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home</a></span> <span>Blog</span></p>
          <h1 class="mb-0 bread">Blog</h1>
        </div> -->
        <div class="col-md-9 ftco-animate pb-5 text-center">
          <h1 class="mb-2 bread"><?php echo e($category->name); ?></h1>
          <p class="breadcrumbs">
            <span class="mr-2">
              <a href="/">Trang chủ &nbsp;<i class="ion-ios-arrow-forward"></i></a>
            </span>
            <span><?php echo e($category->name); ?> &nbsp;<i class="ion-ios-arrow-forward"></i></span>
          </p>
        </div>
      </div>
    </div>
  </div>

  <section class="ftco-section ftco-degree-bg">
    <div class="container">
      <div class="row">
        <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12 d-flex ftco-animate">
          <div class="blog-entry align-self-stretch d-md-flex">
            <a href="/bai-viet/<?php echo e($post->url); ?>" class="block-20" style="background-image: url(<?php echo e(asset($post->image_url)); ?>);">
            </a>
            <div class="text d-block pl-md-4">
              <div class="meta mb-3">
                <div><a><?php echo e($post->day); ?> Thg <?php echo e($post->month); ?> <?php echo e($post->year); ?></a></div>
                <div><a>Admin</a></div>
                <div><a class="meta-chat"><span class="fas fa-eye"></span> <?php echo e($post->views); ?></a></div>
              </div>
              <h3 class="heading"><a href="/bai-viet/<?php echo e($post->url); ?>"><?php echo e($post->name); ?></a></h3>
              <p><?php echo e($post->abstract); ?></p>
              <p><a href="/bai-viet/<?php echo e($post->url); ?>" class="btn btn-primary py-2 px-3">Xem chi tiết</a></p>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <div class="container">
          <div class="row no-gutters slider-text align-items-end justify-content-center">
            <div class="col-md-9 ftco-animate pb-5 text-center">
              <h2 style="color:black;" class="mb-2 bread">Hiện tại không có bài viết nào!</h2>
            </div>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <div class="row mt-5">
        <div class="col text-center">
          <div class="block-27">
            <ul>
              <?php if($currPage > 1): ?>
              <li><a href="<?php echo e($currUrl); ?>?page=<?php echo e($previousPage); ?>">&lt;</a></li>
              <?php endif; ?>
              <?php $__currentLoopData = $listPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($page!= '...'): ?>
              <li class="<?php echo e(($page==$currPage) ? 'active':''); ?>"><a href="<?php echo e($currUrl); ?>?page=<?php echo e($page); ?>"><?php echo e($page); ?></a></li>
              <?php else: ?>
              <li><a>...</a></li>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($currPage < $totalPage): ?> <li><a href="<?php echo e($currUrl); ?>?page=<?php echo e($nextPage); ?>">&gt;</a></li>
                <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\bnsvn\resources\views/category.blade.php ENDPATH**/ ?>