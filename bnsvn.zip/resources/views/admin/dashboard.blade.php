@extends('layouts.admin')
@section('css')
<title>Dashboard</title>
@endsection

@section('body')

@endsection

@section('js')

@endsection